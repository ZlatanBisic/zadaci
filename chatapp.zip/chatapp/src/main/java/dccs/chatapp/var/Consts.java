package dccs.chatapp.var;


public class Consts {
    public static String USER_SESSION = "userSession";
    public static String USER_CHAT = "userChat";
    public static String USER = "userName";
    public static int nesto=0, nesh=0;
}
